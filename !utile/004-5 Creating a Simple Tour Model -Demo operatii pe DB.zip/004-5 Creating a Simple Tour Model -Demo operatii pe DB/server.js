const express = require('express');
const mongoose = require('mongoose');

const app = express();

const dotenv = require('dotenv');
dotenv.config({ path: './config.env' });

// Servește fișiere statice din folderul public
app.use(express.static('public'));


// Conectarea la baza de date MongoDB folosind Mongoose
// !!!modifica datele de conectare in fisierul config.env!!!

const DB = process.env.DATABASE.replace(
  '<db_password>',
  process.env.DATABASE_PASSWORD
);

const tourSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'A tour must have a name'],
    unique: true,
  },
  rating: {
    type: Number,
    default: 4.5,
  },
  price: {
    type: Number,
    required: [true, 'A tour must have a price'],
  },
});

mongoose
  .connect(DB)
  .then(async () => {
    console.log('Conexiune reușită la baza de date!');

    // Obținem lista colecțiilor
    const collections = await mongoose.connection.db
      .listCollections()
      .toArray();

    //prima oara nu vor fi afisate colectii, colectia se va crea la prima adaugare de document, pe ruta /adauga
    if (collections.length === 0) {
      console.log('Nu există colecții în baza de date.');
    } else {
      console.log('Colecțiile din baza de date sunt:');
      collections.forEach((col) => console.log(`- ${col.name}`));
    }


  })
  .catch((err) => console.error('Eroare la conectare:', err));


const Tour = mongoose.model('Tour', tourSchema);



// Ruta '/' pentru index.html
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});


app.get('/adauga', (req, res) => {
  const testTour = new Tour({
    name: 'The Forest Hiker' + Math.random().toString(36).substring(7),
    rating: 4.7,
    price: 497,
  });

  testTour
    .save()
    .then((doc) => {
      doc = JSON.stringify(doc, null, 2);
      const mesaj = `<pre>Tour salvat în baza de date: + ${doc}</pre>`;
      res.send(mesaj);
    })
    .catch((err) => {
      err = JSON.stringify(err, null, 2);
      const errorMsg = `<pre>Eroare la salvarea tour-ului: ${err}</pre>`;
      res.status(500).send(errorMsg);
    });
});

app.get('/list-all', (req, res) => {
  Tour.find()
    .then((tours) => {
      res.json(tours);
    })
    .catch((err) => {
      res.status(500).send('Eroare la preluarea tour-urilor.');
    });
});

app.get('/delete-first', async (req, res) => {
  try {

    const deleted = await Tour.findOneAndDelete({}, { sort: { _id: 1 } });
    if (!deleted) return res.status(404).send('Nu există elemente în colecție');
    res.json({ message: 'Primul element a fost șters', deleted });
  } catch (err) {
    res.status(500).send(err.message);
  }
});


const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`App running on port ${port}...`);
});
